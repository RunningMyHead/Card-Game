using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//�¼���Ԫ
public class EventUnit
{
    public virtual void Init()//��ʼ��
    {

    }

    public virtual void OnUpDate()//ÿִ֡��
    {

    }
}
