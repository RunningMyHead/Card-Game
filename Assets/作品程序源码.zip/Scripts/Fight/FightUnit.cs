using System.Collections;
using System.Collections.Generic;
using UnityEngine;

//ս����Ԫ
public class FightUnit
{    
    public virtual void Init()//��ʼ��
    {
        
    }
}
